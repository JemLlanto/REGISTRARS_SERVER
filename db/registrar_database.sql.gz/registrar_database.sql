-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 20, 2025 at 04:04 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `registrar_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `classification`
--

CREATE TABLE `classification` (
  `classID` int(11) NOT NULL,
  `className` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `classification`
--

INSERT INTO `classification` (`classID`, `className`) VALUES
(1, 'Undergraduate'),
(2, 'Graduated');

-- --------------------------------------------------------

--
-- Table structure for table `document_selection`
--

CREATE TABLE `document_selection` (
  `documentID` int(11) NOT NULL,
  `purposeID` int(11) NOT NULL,
  `documentName` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `program_course`
--

CREATE TABLE `program_course` (
  `programID` int(11) NOT NULL,
  `programName` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `program_course`
--

INSERT INTO `program_course` (`programID`, `programName`) VALUES
(1, 'BS Electrical Engineering'),
(2, 'BS Computer Engineering'),
(3, 'Bachelor of Secondary Education'),
(4, 'BS Industrial Education'),
(5, 'Bachelor of Technical Vocational Teacher Education'),
(6, 'BS Industrial Technology'),
(7, 'BS Hotel and Restaurant Management'),
(8, 'BS Hospitality Management'),
(9, 'BS Business Management'),
(10, 'BS Business Administration'),
(11, 'BS Computer Science'),
(12, 'BS Information Technology'),
(13, 'Bachelor of Technical Teacher Education'),
(14, 'Diploma in Hotel and Restaurant Management'),
(15, 'Associate in Computer Technology'),
(16, 'Associate of Technology'),
(17, 'Diploma of Technology'),
(18, 'Teacher Certificate Program'),
(19, 'Laboratory Science High School(SELS)'),
(20, 'STVC');

-- --------------------------------------------------------

--
-- Table structure for table `purpose`
--

CREATE TABLE `purpose` (
  `purposeID` int(11) NOT NULL,
  `purposeName` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `purpose`
--

INSERT INTO `purpose` (`purposeID`, `purposeName`) VALUES
(1, 'For Employment - Local'),
(2, 'For Employment - Abroad'),
(3, 'For Transfer'),
(4, 'For Masteral Studies'),
(5, 'For Scholarship'),
(6, 'Copy for School'),
(7, 'Others'),
(8, 'For Board Exam'),
(9, 'For TCP/CTE');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userID` int(15) NOT NULL,
  `isAdmin` int(15) NOT NULL DEFAULT 0,
  `firstName` varchar(100) NOT NULL,
  `lastName` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userID`, `isAdmin`, `firstName`, `lastName`, `email`, `password`) VALUES
(8, 0, 'asd', 'asd', 'asd@gmail.com', '$2b$10$Dy.LTdoXEzKBKxBe/Nkik.tUJ.ovMTnYTwzj1SeamoytK7l6JLvRe'),
(9, 0, 'asd', 'asd', 'asdasd@gmail.com', '$2b$10$Dy.LTdoXEzKBKxBe/Nkik.tUJ.ovMTnYTwzj1SeamoytK7l6JLvRe'),
(10, 0, 'qwe', 'qwe', 'qwe@gmail.com', '$2b$10$4Xc/exsHJobu4D/8EkCr5.RAuOE9Yd55YL.fE4JE8H/xwclyGCywa'),
(11, 0, 'zxc', 'zxc', 'zxc@gmail.com', '$2b$10$RLGvqdpwjbo9lWV0ha4GVuspvtp7iKWz5XdJmi5HMVB2xvZidZ/Ti');

-- --------------------------------------------------------

--
-- Table structure for table `year_level`
--

CREATE TABLE `year_level` (
  `yearID` int(11) NOT NULL,
  `yearName` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `year_level`
--

INSERT INTO `year_level` (`yearID`, `yearName`) VALUES
(1, 'First Year'),
(2, 'Second Year'),
(3, 'Third Year'),
(4, 'Fourth Year'),
(5, 'Fifth Year');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `classification`
--
ALTER TABLE `classification`
  ADD PRIMARY KEY (`classID`);

--
-- Indexes for table `document_selection`
--
ALTER TABLE `document_selection`
  ADD PRIMARY KEY (`documentID`);

--
-- Indexes for table `program_course`
--
ALTER TABLE `program_course`
  ADD PRIMARY KEY (`programID`);

--
-- Indexes for table `purpose`
--
ALTER TABLE `purpose`
  ADD PRIMARY KEY (`purposeID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`);

--
-- Indexes for table `year_level`
--
ALTER TABLE `year_level`
  ADD PRIMARY KEY (`yearID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `classification`
--
ALTER TABLE `classification`
  MODIFY `classID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `document_selection`
--
ALTER TABLE `document_selection`
  MODIFY `documentID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `program_course`
--
ALTER TABLE `program_course`
  MODIFY `programID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `purpose`
--
ALTER TABLE `purpose`
  MODIFY `purposeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userID` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `year_level`
--
ALTER TABLE `year_level`
  MODIFY `yearID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
